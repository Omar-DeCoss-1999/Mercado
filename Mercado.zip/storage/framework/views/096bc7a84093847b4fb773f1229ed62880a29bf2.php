

<?php $__env->startSection('cartas'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Editar usuario</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="/usuarios">Regresar</a>
            <br> <center> <?php echo $errors->first('correo', '<span class="help-block">:message</span>'); ?> </center>
        </div>
    </div>
</div>

<form action="/usuarios/<?php echo e($usuario->id); ?>/update" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nombre:</strong>
                <input type="text" name="nombre" value="<?php echo e($usuario->nombre); ?>" class="form-control" placeholder="Usuario">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Apellido paterno:</strong>
                <input type="text" name="a_pat" value="<?php echo e($usuario->a_paterno); ?>" class="form-control" placeholder="Apellido paterno">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Apellido materno:</strong>
                <input type="text" name="a_mat" value="<?php echo e($usuario->a_materno); ?>" class="form-control" placeholder="Apellido materno">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Correo:</strong>
                <input type="text" name="correo" value="<?php echo e($usuario->correo); ?>" class="form-control" placeholder="Correo electronico">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Foto de perfil:</strong>
                <input type="file" name="imagen" value="<?php echo e($usuario->imagen); ?>" class="form-control" placeholder="Selecciona">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Rol:</strong>
                <select class="form-control" name="rol" id="rol">
                    <?php if($usuario->rol == 'Supervisor'): ?>
                    <option selected>Supervisor</option>
                    <?php else: ?>
                    <option>Supervisor</option>
                    <?php endif; ?>
                    <?php if($usuario->rol == 'Encargado'): ?>
                    <option selected>Encargado</option>
                    <?php else: ?>
                    <option>Encargado</option>
                    <?php endif; ?>
                    <?php if($usuario->rol == 'Contador'): ?>
                    <option selected>Contador</option>
                    <?php else: ?>
                    <option>Contador</option>
                    <?php endif; ?>
                    <?php if($usuario->rol == 'Cliente'): ?>
                    <option selected>Cliente</option>
                    <?php else: ?>
                    <option>Cliente</option>
                    <?php endif; ?>
                </select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Contraseña:</strong>
                <input type="password" name="password" class="form-control" placeholder="Ingresa tu contraseña">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Contraseña de verificación:</strong>
                <input type="password" name="password2" class="form-control" placeholder="Ingresa nueevamente tu contraseña">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Enviar</button>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Usuarios/edit.blade.php ENDPATH**/ ?>