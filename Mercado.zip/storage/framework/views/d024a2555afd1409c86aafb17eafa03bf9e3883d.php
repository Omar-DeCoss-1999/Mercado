
<?php $__env->startSection('cartas'); ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Imagen</td>
            <td>Nombre</td>
            <td>Descripción</td>
            <td>Precio</td>
            <td>Stock</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $mis_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td>
              <img src="<?php echo e(asset('storage').'/'.'productos'.'/'.$productos->imagen); ?>" width="150px" height="150px">
            </td>
            <td><?php echo e($productos->nombre); ?></td>
            <td><?php echo e($productos->descripcion); ?></td>
            <td>$ <?php echo e($productos->precio); ?></td>
            <td><?php echo e($productos->cantidad); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="5">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Usuarios/misproductos.blade.php ENDPATH**/ ?>