

<?php $__env->startSection('cartas'); ?>
<h2>Mis productos comprados</h2>
<a href="/" class="btn btn-primary">Regresar</a>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Imagen</td>
            <td>Producto</td>
            <td>Precio</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td>
              <img src="<?php echo e(asset('storage').'/'.'productos'.'/'.$productos->imagen); ?>" width="150px" height="150px">
            </td>
            <td><?php echo e($productos->nombre); ?></td>
            <td>$<?php echo e($productos->precio); ?></td>
            <td>
                <form action="/comprobante/<?php echo e($productos->id); ?>" method="POST"
                  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="file" name="captura">
                    <label>Calificación:
                        <input type="number" name="calificacion">
                    </label>
                    <button type="submit" class="btn btn-success">Enviar comprobante</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="4">Aún no has comprado ningun producto</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Usuarios/productosComprados.blade.php ENDPATH**/ ?>