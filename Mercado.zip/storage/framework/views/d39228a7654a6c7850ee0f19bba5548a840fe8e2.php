
<?php $__env->startSection('cartas'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Compra</h2>
            <!-- Acá va la imagen del comprobante -->
            <h4><img src="" width="50px" height="50px">
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Producto</strong>
            <?php echo e($compras->nombre); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Precio</strong>
            <?php echo e($compras->precio); ?>

        </div>
    </div>
</div>

<form action="">
    <?php echo csrf_field(); ?>
    <strong>En caso de ser rechazado</strong>
    <input type="text" name="pregunta" class="form-control" placeholder="Ingresa los motivos aquí">
    <input type="submit" class="btn btn-danger" value="Rechazar">
    <a href="">Autorizar compra</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Tablero/autorizar.blade.php ENDPATH**/ ?>