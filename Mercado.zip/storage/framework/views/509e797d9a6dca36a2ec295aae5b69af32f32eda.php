
<?php $__env->startSection('cartas'); ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Comprobante de pago</td>
            <td>Producto</td>
            <td>Precio</td>
            <td>Cantidad</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <br> <center> <?php echo $errors->first('correo', '<span class="help-block">:message</span>'); ?> </center>
        <?php $__empty_1 = true; $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php if($compra->c_pago != "No hay comprobante"): ?>
        <?php if($compra->compra_autorizada != 1): ?>
        <tr>
            <td>
              <center>
                <img src="<?php echo e(asset('storage').'/'.'compro_pago'.'/'.$compra->c_pago); ?>" width="250px" height="250px">
              </center>
            </td>
            <td><?php echo e($compra->nombre); ?></td>
            <td>$<?php echo e($compra->precio); ?></td>
            <td><?php echo e($compra->cantidad); ?></td>
            <td>
                <!-- <a href="/autorizar/<?php echo e($compra->id); ?>" type="submit" class="btn btn-primary">Autorizar compra</a> -->
                <form action="/autorizacion_rechazo/<?php echo e($compra->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <strong>En caso de ser rechazado</strong>
                    <input type="text" name="motivos" class="form-control" placeholder="Ingresa los motivos aquí">
                    <br>
                    <input type="submit" class="btn btn-danger" value="Rechazar">
                    <a href="/autorizacion_aceptado/<?php echo e($compra->id); ?>" type="submit" class="btn btn-primary">Autorizar compra</a>
                </form>
            </td>
        </tr>
        <?php endif; ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="5">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Tablero/conta.blade.php ENDPATH**/ ?>