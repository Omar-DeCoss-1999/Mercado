
<?php $__env->startSection('cartas'); ?>
<table class="table table-bordered">
    <tr>
        <th>Comentarios</th>
        <th>Total</th>
        <th>Estado</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $mis_pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pagos_usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td> <?php echo e($pagos_usu->nota); ?> </td>
        <td> $<?php echo e($pagos_usu->pago); ?> </td>
        <?php if(Auth::user()->rol == "Contador"): ?>
        <?php if($pagos_usu->autorizado == 0): ?>
        <td style="
                background:rgb(225, 111, 111);"> Pago no autorizado
        </td>
        <?php else: ?>
        <td> pago autorizado</td>
        <?php endif; ?>
        <?php elseif(Auth::user()->rol == "Cliente"): ?>
        <?php if($pagos_usu->autorizado == 0): ?>
        <td style="
                background:rgb(225, 111, 111);">
            <form action="/aceptar_pago/<?php echo e($pagos_usu->id); ?>" method="get">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php if($pagos_usu->recibido == 0): ?>
                <input type="submit" class="btn btn-success" value="Retirar">
                <?php endif; ?>
            </form>
        </td>
        <?php else: ?>
        <td>Pago aceptado</td>
        <?php endif; ?>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="5">sin registro</td>
    </tr>
    <?php endif; ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Usuarios/mispagos.blade.php ENDPATH**/ ?>