

<?php $__env->startSection('nombreU'); ?>
<span class="mr-2 d-none d-lg-inline text-gray-600 small">Anónimo</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('fotoP'); ?>
<img class="img-profile rounded-circle" src="img/undraw_profile.svg">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('opciones'); ?>
<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
        <i class="fas fa-fw fa-folder"></i>
        <span>Categorías</span>
    </a>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a class="collapse-item" href=""><?php echo e($categorias->nombre); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <a class="collapse-item" href="">Sin registro</a>
            <?php endif; ?>
        </div>
    </div>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('usuarioOpciones'); ?>
<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
    <a class="dropdown-item" href="login">
        <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
        Iniciar sesión
    </a>
    <a class="dropdown-item" href="register">
        <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
        Registrarse
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cartas'); ?>
<table class="table col-12 table-responsive">
    <thead>
        <tr>
            <td>Imagen</td>
            <td>Producto</td>
            <td>Descripción</td>
            <td>Precio</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><img src="<?php echo e(asset('/perfil_img/'.$products->imagen)); ?>" width="50px" height="50px"></td>
            <td><?php echo e($products->nombre); ?></td>
            <td><?php echo e($products->descripcion); ?></td>
            <td><?php echo e($products->precio); ?></td>
            <td><button class="btn btn-round">Ver</button></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="3">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Roles/anonimo.blade.php ENDPATH**/ ?>