
<?php $__env->startSection('cartas'); ?>

<h2>Categorias exitentes</h2>
<?php if(Auth::user() == null): ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Categoria</td>
            <td>Descripción</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($categorias->nombre); ?></td>
            <td><?php echo e($categorias->descripcion); ?></td>
            <td>
                <form action="productos/<?php echo e($categorias->id); ?>/index" method="GET">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary">Mostrar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="3">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php elseif(Auth::user()->rol == 'Cliente'): ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <td>Categoria</td>
            <td>Descripción</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($categorias->nombre); ?></td>
            <td><?php echo e($categorias->descripcion); ?></td>
            <td>
                <form action="productos/<?php echo e($categorias->id); ?>/index" method="GET">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary">Mostrar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="3">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php elseif(Auth::user()->rol == 'Encargado'): ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Categoria</td>
            <td>Descripción</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($categorias->nombre); ?></td>
            <td><?php echo e($categorias->descripcion); ?></td>
            <td>
                <form action="productos/<?php echo e($categorias->id); ?>/index" method="GET">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary">Mostrar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="3">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php elseif(Auth::user()->rol == 'Supervisor'): ?>
<a href="crearCategoria" class="btn btn-success">Agregar una nueva categoría</a>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Categoria</td>
            <td>Descripción</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($categorias->nombre); ?></td>
            <td><?php echo e($categorias->descripcion); ?></td>
            <td>
                <form action="categorias/<?php echo e($categorias->id); ?>" method="POST">
                    <a class="btn btn-info" href="productos/<?php echo e($categorias->id); ?>/index">Mostrar</a>
                    <a class="btn btn-primary" href="/editar/<?php echo e($categorias->id); ?>">Editar</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="3">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Categorias/index.blade.php ENDPATH**/ ?>