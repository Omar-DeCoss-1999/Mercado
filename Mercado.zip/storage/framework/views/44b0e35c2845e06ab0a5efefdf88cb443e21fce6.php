
<?php $__env->startSection('buscar'); ?>
<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="/productos/<?php echo e($id_categoria); ?>/buscarpor" method="GET">
    <?php echo csrf_field(); ?>
    <div class="input-group">
        <input name="busqueda" type="text" class="form-control bg-light border-0 small" placeholder="Buscar un producto" aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
            <button class="btn btn-primary" type="submit">
                <i class="fas fa-search fa-sm"></i>
            </button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cartas'); ?>
<h2>Productos exitentes</h2>
<div class="pull-right">
    <a class="btn btn-primary" href="/">Regresar</a>
</div>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Producto::class)): ?>
<a href="/crearProducto" class="btn btn-success">Proponer</a>
<?php endif; ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Imagen</td>
            <td>Nombre</td>
            <td>Descripción</td>
            <td>Precio</td>
            <td>Stock</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td>
              <img src="<?php echo e(asset('storage').'/'.'productos'.'/'.$productos->imagen); ?>" width="150px" height="150px">
            </td>
            <td><?php echo e($productos->nombre); ?></td>
            <td><?php echo e($productos->descripcion); ?></td>
            <td>$ <?php echo e($productos->precio); ?></td>
            <td><?php echo e($productos->cantidad); ?></td>
            <td>
                <a class="btn btn-info" href="/productos/<?php echo e($productos->id); ?>/show">Ver</a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar', $productos)): ?>
                <a class="btn btn-primary" href="/editarProducto/<?php echo e($productos->id); ?>">Editar</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comprar', $productos)): ?>
                <form action="/comprar/<?php echo e($productos->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="submit" class="btn btn-success" value="Comprar">
                </form>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $productos)): ?>
                <form action="/deleteProducto/<?php echo e($productos->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="submit" class="btn btn-danger" value="Eliminar">
                </form>
                <?php endif; ?>
                <a class="btn btn-info" href="">Validar</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="5">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Productos/index.blade.php ENDPATH**/ ?>