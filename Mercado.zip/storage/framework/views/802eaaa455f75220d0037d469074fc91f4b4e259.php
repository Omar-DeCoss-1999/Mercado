

<?php $__env->startSection('cartas'); ?>
<?php if(Auth::user()->rol != 'Contador'): ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Usuario</h2>
            <h4><img src="<?php echo e(asset('storage').'/'.'usuarios'.'/'.$usuario->imagen); ?>" width="250px" height="250px">
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="/usuarios">Regresar</a>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Nombre:</strong>
            <?php echo e($usuario->nombre); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Apellido paterno:</strong>
            <?php echo e($usuario->a_paterno); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Apellido materno:</strong>
            <?php echo e($usuario->a_materno); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Correo:</strong>
            <?php echo e($usuario->correo); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Rol:</strong>
            <?php echo e($usuario->rol); ?>

        </div>
    </div>
</div>
<?php endif; ?>
<?php if(Auth::user()->rol == 'Contador'): ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Producto</td>
            <td>Precio</td>
            <td>Cantidad</td>
            <td>TOTAL</td>
        </tr>
    </thead>
    <tbody>
      <?php $acumulador = 0; ?>
      <?php $id_usuario = 0; ?>
      <center> <?php echo $errors->first('correo', '<span class="help-block">:message</span>'); ?> </center>
      <?php $__empty_1 = true; $__currentLoopData = $produ_elegidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produ_elegido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($produ_elegido->nombre); ?></td>
            <td>$<?php echo e($produ_elegido->precio); ?></td>
            <td><?php echo e($produ_elegido->cantidad); ?></td>
            <td>$<?php echo e($produ_elegido->precio * $produ_elegido->cantidad); ?></td>
            <?php $acumulador += $produ_elegido->precio * $produ_elegido->cantidad; ?>
        </tr>
        <?php $id_usuario = $produ_elegido->id_usuarios; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="5">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<label>Total a pagar = $<?php echo($acumulador); ?></label>
<form action="<?php echo e(url('pago_cliente', ['id1' => $acumulador, 'id2' => $id_usuario])); ?>" method="get">
  <?php echo csrf_field(); ?>
    <label>Gatos extras:</label>
    <input type="text" name="fletes" placeholder="Gastos extras">
    <label>Nota:</label>
    <input type="text" name="nota" placeholder="Ingrese una nota">
    <input type="submit" value="Pagar">
</form>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Usuarios/show.blade.php ENDPATH**/ ?>