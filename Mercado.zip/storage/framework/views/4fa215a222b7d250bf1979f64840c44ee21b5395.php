

<?php $__env->startSection('cartas'); ?>
<h2>Usuarios exitentes</h2>
<?php if(Auth::user()->rol == 'Supervisor'): ?>
<a href="/usuarios/create" class="btn btn-success">Agregar una nuevo usuario</a>
<?php endif; ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <td>Imagen</td>
            <td>Usuario</td>
            <td>Correo</td>
            <td>Rol</td>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td>
              <img src="<?php echo e(asset('storage').'/'.'usuarios'.'/'.$usuarios->imagen); ?>" width="100px" height="100px">
            </td>
            <td><?php echo e($usuarios->nombre); ?></td>
            <td><?php echo e($usuarios->correo); ?></td>
            <td><?php echo e($usuarios->rol); ?></td>
            <td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar', App\Models\Usuario::class)): ?>
                <a class="btn btn-info" href="/usuarios/<?php echo e($usuarios->id); ?>/show">Mostrar</a>
                <form action="/usuarios/delete/<?php echo e($usuarios->id); ?>" method="POST">
                    <a class="btn btn-primary" href="/usuarios/<?php echo e($usuarios->id); ?>/edit">Editar</a>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
                <?php endif; ?>
                <br>
                <?php if(Auth::user()->rol == 'Encargado'): ?>
                <a type="submit" class="btn btn-success" href="/restablecer/<?php echo e($usuarios->id); ?>">Restablecer contraseña</a>
                <?php endif; ?>
                <?php if(Auth::user()->rol == 'Contador'): ?>
                <a class="btn btn-success" href="/">Generar pago</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr align="center">
            <td colspan="5">Sin registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/Usuarios/index.blade.php ENDPATH**/ ?>