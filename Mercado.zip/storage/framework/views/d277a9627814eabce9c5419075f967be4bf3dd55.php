

<?php $__env->startSection('cartas'); ?>
<h2>Cambio de contraseña</h2>
<form action="/usuarios/restablecer/<?php echo e($usuario->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="inputBx">
        <span>Ingrese la nueva contraseña</span>
        <input type="password" name="password" class="form-control" placeholder="Ingrese su contraseña">
        <?php echo $errors->first('password', '<span class="help-block">:message</span>'); ?>

    </div>
    <div class="inputBx">
        <span>Verefique contraseña</span>
        <input type="password" class="form-control" name="password2" placeholder="Verifique su contraseña">
    </div>
    <div class="inputBx">
        <input type="submit" class="btn btn-success" value="Actualizar">
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Tablero.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Mercado/resources/views/restablecerP_U.blade.php ENDPATH**/ ?>